var ground;
var bananaimage;
var obstacleimage;
var score;
var background;
var obstaclegroup;
var foodgroup;
var animal;

function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
  ground.visible=false;
  if(foodgroup.isTouching(animal)){
  score=+2;
  foodgroup.desteroyEach;  
  
  }
  switch(score){
    case:10 animal.scale=0.12; 
      break;
      case:20 animal.scale=0.14;
      break;
      case:30 animal.scale=0.16;
      break;
      case:40 animal.scale=0.18;
      break;
      default:break;
  }
  if(obstaclesgroup.isTouching(animal)){
    animal.scale=0.2;
    
    
  }
}